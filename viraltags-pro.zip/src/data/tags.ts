import { CategoryKey } from './categories';

export interface KeywordTagResult {
  primaryKeywords: string[];
  secondaryKeywords: string[];
  seoSearchPhrases: string[];
  commaSeparatedTags: string;
  hashtagBundle: string;
}

export function generateKeywordsAndTags(topic: string, category: CategoryKey): KeywordTagResult {
  const cleanTopic = topic.trim().toLowerCase() || category.toLowerCase();
  const words = cleanTopic.split(/\s+/).filter((w) => w.length > 1);

  // Generate SEO keywords for Instagram search bar
  const primaryKeywords = [
    cleanTopic,
    `${cleanTopic} tips`,
    `${cleanTopic} ideas`,
    `${cleanTopic} inspiration`,
    `best ${cleanTopic}`,
    `${cleanTopic} tutorial`,
    `${cleanTopic} aesthetic`,
  ];

  const secondaryKeywords = [
    `how to ${cleanTopic}`,
    `${cleanTopic} creator`,
    `${cleanTopic} trends 2026`,
    `${cleanTopic} daily`,
    `${cleanTopic} guide`,
    `viral ${cleanTopic}`,
    `${cleanTopic} for beginners`,
    `${cleanTopic} secret`,
  ];

  const seoSearchPhrases = [
    `Instagram ${cleanTopic} strategy`,
    `Aesthetic ${cleanTopic} content`,
    `${category} reels audio trends`,
    `Trending ${cleanTopic} recommendations`,
    `Best captions and tags for ${cleanTopic}`,
  ];

  // Tag bundles
  const tagList = [
    ...words.map((w) => `#${w}`),
    `#${cleanTopic.replace(/\s+/g, '')}`,
    `#${category.toLowerCase()}community`,
    `#${category.toLowerCase()}tips`,
    `#${category.toLowerCase()}daily`,
    `#${cleanTopic.replace(/\s+/g, '')}trend`,
    `#${cleanTopic.replace(/\s+/g, '')}inspo`,
    `#${cleanTopic.replace(/\s+/g, '')}creator`,
  ];

  const uniqueTags = Array.from(new Set(tagList));

  return {
    primaryKeywords,
    secondaryKeywords,
    seoSearchPhrases,
    commaSeparatedTags: [...primaryKeywords, ...secondaryKeywords].join(', '),
    hashtagBundle: uniqueTags.join(' '),
  };
}
