import { Language } from './categories';

export type CaptionTone =
  | 'Funny'
  | 'Cool'
  | 'Emotional'
  | 'Romantic'
  | 'Motivational'
  | 'Professional'
  | 'Attitude'
  | 'Inspirational';

export const CAPTION_TONES: CaptionTone[] = [
  'Funny',
  'Cool',
  'Emotional',
  'Romantic',
  'Motivational',
  'Professional',
  'Attitude',
  'Inspirational',
];

interface ToneTemplate {
  templates: ((topic: string) => string)[];
}

const CAPTION_GENERATOR_DATA: Record<CaptionTone, Record<Language, ToneTemplate>> = {
  Funny: {
    English: {
      templates: [
        (t) => `I told myself I wouldn't post about ${t}, but here we are. Self-control: 0, Me: 1. 😂🤦‍♂️`,
        (t) => `Behind every picture of ${t} is 47 failed attempts and a dying battery. 📱💀`,
        (t) => `My brain: "Act normal." Me with ${t}: "Absolutely not." 🙃✨`,
        (t) => `If loving ${t} was a crime, I'd already be serving a life sentence. 🚨🤣`,
        (t) => `Current status: Holding it all together with iced coffee and thoughts of ${t}. ☕️⚡️`,
        (t) => `I need a six-month vacation twice a year, especially after dealing with ${t}. 🏖️😴`,
        (t) => `They said follow your dreams, so I ended up with ${t}. Expectation vs reality hits different! 🤪✌️`,
        (t) => `Proof that I actually did something regarding ${t} today instead of just scrolling Reels. 🏆👀`,
        (t) => `My therapist told me to find inner peace. I found ${t} instead. Close enough! 🧘‍♀️🍕`,
        (t) => `Not to brag, but I didn't cry once while handling ${t} today. Mature adult behavior! 🫡✨`,
      ],
    },
    Hindi: {
      templates: [
        (t) => `${t} के चक्कर में ज़िंदगी में सिर्फ़ ड्रामा और रील्स ही बची हैं! 😂✌️`,
        (t) => `सोचा था ${t} संभाल लूंगा, लेकिन अब ${t} मुझे संभाल रहा है। 💀🤦‍♂️`,
        (t) => `जितनी शिद्दत से मैंने ${t} चाहा है, उतनी शिद्दत से तो नींद भी नहीं आती! 😴🤣`,
        (t) => `फ़ोन की बैटरी 2% और ${t} का खुमार 100%! यही है असली जिंदगी। 📱⚡️`,
        (t) => `लोग प्यार में पागल होते हैं, हम ${t} के चक्कर में! बस चाय मिल जाए तो सब ठीक। ☕️🤪`,
        (t) => `मम्मी ने कहा था तमीज़ सीखो, मैंने ${t} सीख लिया। काम तो चल ही रहा है! 🫡😂`,
        (t) => `जब तक ${t} का फोटो पोस्ट न हो, खाना हज़म नहीं होता। सच बताओ किस-किस का ये हाल है? 👀🍕`,
        (t) => `सैलरी ख़त्म हो जाती है पर ${t} का शौक कभी नहीं! हे भगवान, अमीर बना दो। 💸🙌`,
        (t) => `दिमाग़: पढ़ाई कर लो। दिल: चल ${t} के मज़े लेते हैं! दिल हमेशा जीतता है। 🧠💔`,
        (t) => `${t} देख कर जो सुकून मिलता है, वो संडे की दोपहर की नींद में भी नहीं! ☀️😆`,
      ],
    },
    Assamese: {
      templates: [
        (t) => `${t} ৰ নামত যিমান চিন্তা, সিমান যদি পঢ়াত দিলোঁহেঁতেন তেন্তে ডক্টৰেট হৈ গ'লহেঁতেন! 😂🤦‍♂️`,
        (t) => `মই আৰু ${t}—এখন চিৰকলীয়া ধেমালিৰ নাটক! কাকো দেখুৱাব নোৱাৰি। 🤪🎭`,
        (t) => `চাহৰ কাপ আৰু ${t} ৰ কথা, দুয়োটাই যদি থাকে দিনটো শেষলৈ হাঁহি থাকিব পাৰি! ☕️✨`,
        (t) => `${t} কৰিম বুলি ভাবি কেৱল ৰীল চাই সময় পাৰ কৰা মানুহ মই! হাত ডাঙক কোন কোন আছে? 🙋‍♂️💀`,
        (t) => `মনটোৱে কয় শান্ত হোৱা, কিন্তু ${t} এ কয় আৰু অলপ পাগল হোৱা! 🙃🔥`,
        (t) => `বাজেট কম কিন্তু ${t} ৰ প্ৰতি থকা হেঁপাহ হিমালয়তকৈও ওখ! 💸🏔️`,
        (t) => `আজিৰ দিনটোৰ একমাত্ৰ প্ৰাপ্তি: ${t} ৰ লগত কটোৱা এই কেইটা মুহূৰ্ত! ✌️😆`,
        (t) => `${t} ৰ কাহিনী শুনিলে হাঁহি হাঁহি পেটৰ বিষ হ'ব! কাহিনীটো বৰ ৰসাল। 🤣`,
        (t) => `মোৰ জীৱনৰ ৫০% চিন্তা ভাত কি খাম, আৰু বাকী ৫০% ${t} কিদৰে কৰিম! 🍚🤔`,
        (t) => `কাম একো নাই কিন্তু ${t} ৰ বৰ্ণনা শুনাবলৈ সদায় সাজু! অসমীয়াৰ স্বভাৱেই এনেকুৱা। 😜🤙`,
      ],
    },
  },
  Cool: {
    English: {
      templates: [
        (t) => `Built different when it comes to ${t}. No noise, just vibes. 🕶️⚡️`,
        (t) => `Less talking, more doing. That's the formula for ${t}. 🖤🚀`,
        (t) => `Elevating standards with ${t}. Never competing, just creating. 🍸🔥`,
        (t) => `Catch flights, chase ${t}, stay unbothered. ✈️✨`,
        (t) => `Energy is currency. Investing strictly in ${t} this season. 💎📈`,
        (t) => `In my own lane, minding my business and mastering ${t}. 🏎️💨`,
        (t) => `Subtle flex, quiet moves. All about that ${t} energy. 🌌🧊`,
        (t) => `Don't chase, attract. Let ${t} do the talking. 💫🎯`,
        (t) => `Classic style, modern mindset, obsessed with ${t}. 🕶️♟️`,
        (t) => `Unapologetically focused on ${t}. That's that. 🪐🏆`,
      ],
    },
    Hindi: {
      templates: [
        (t) => `शोर मचाने की ज़रूरत नहीं, ${t} का नतीजा खुद बोलता है। 🕶️🔥`,
        (t) => `स्टाइल अपना, सोच अलग, और फोकस सिर्फ़ ${t} पर। 🖤⚡️`,
        (t) => `भीड़ में चलना हमारी आदत नहीं, जब बात ${t} की हो तो रास्ता खुद बनाते हैं। 🚀👑`,
        (t) => `कम बोलो, काम ज़्यादा करो। ${t} का यही असली रूल है। ♟️🎯`,
        (t) => `जो हमें पसंद है वो हम करते हैं, और फ़िलहाल वो है सिर्फ़ ${t}! 🍸✨`,
        (t) => `ख़ामोशी में की गई मेहनत जब ${t} बनकर सामने आती है तो सब देखते रह जाते हैं। 💎🙌`,
        (t) => `नो ड्रामा, सिर्फ़ काम और ${t} के साथ अपना मस्त अंदाज़। 🏎️💨`,
        (t) => `हमारी पहचान हमारी सादगी और ${t} के प्रति हमारा जुनून है। 🌌🧊`,
        (t) => `ब्रांड बनने में वक़्त लगता है, शुरुआत आज ${t} से हो चुकी है। 🏆💫`,
        (t) => `वक़्त भी बदलेगा और नज़ारे भी, जब ${t} अपना कमाल दिखाएगा। 🪐🔥`,
      ],
    },
    Assamese: {
      templates: [
        (t) => `শব্দৰ প্ৰয়োজন নাই, ${t} ৰ উত্তৰ কামেই দিব। 🕶️⚡️`,
        (t) => `নিজৰ পথ, নিজৰ গতি। ${t} ৰ লগত সদায় আছুতীয়া। 🖤🚀`,
        (t) => `শান্তিৰে কাম কৰা, সফলতাৰ চিঞৰ সকলোৱে শুনিব। ${t} ত মনোযোগ! 🍸💎`,
        (t) => `অসমীয়া তেজ আৰু ${t} ৰ প্ৰতি অনন্য টান—এয়াই আমাৰ চিনাকী! 🔥👑`,
        (t) => `কাৰো লগত প্ৰতিযোগিতা নাই, ${t} ৰ লগত নিজক উন্নত কৰাৰ যুদ্ধ। 🎯🏎️`,
        (t) => `সহজ সৰল ব্যক্তিত্ব, কিন্তু ${t} ৰ ক্ষেত্ৰত কোনো আপোচ নাই। 🌌🧊`,
        (t) => `যি কৰিম মনৰ পৰা কৰিম, বিশেষকৈ যেতিয়া কথাটো ${t} ৰ হয়। 💫🏆`,
        (t) => `অহংকাৰ নহয়, নিজৰ কামৰ প্ৰতি আত্মবিশ্বাস—বিশেষকৈ ${t} ত! ♟️✨`,
        (t) => `ভিতৰি শান্ত, বাহিৰত শক্তিশালী—${t} ৰ এই নতুন গতি। 🪐🌊`,
        (t) => `আজিৰ সপোন, কাইলৈৰ বাস্তৱ—যাত্ৰাত আছে কেৱল ${t}। 🚀🖤`,
      ],
    },
  },
  Emotional: {
    English: {
      templates: [
        (t) => `Some moments leave footprints on the soul. Forever thankful for ${t}. 🥺❤️`,
        (t) => `It’s not just about ${t}; it’s about the memories, the scars, and the growth. 🌧️🕊️`,
        (t) => `Holding onto the little things because ${t} taught me how precious time really is. ⏳🤍`,
        (t) => `Sometimes you don't realize the value of ${t} until it becomes a treasured memory. 🍂💫`,
        (t) => `Quiet heart, loud thoughts, and a deep longing connected to ${t}. 💭🌙`,
        (t) => `The hardest journeys lead to the sweetest destinations, just like ${t}. 🥀✨`,
        (t) => `If tears could speak, they’d tell stories about ${t} that words never could. 🌊🖤`,
        (t) => `Cherishing every heartbeat and every second spent understanding ${t}. 🫂🌸`,
        (t) => `A piece of my heart will always belong to ${t}. No matter where life takes me. 🕯️🕊️`,
        (t) => `Raw, unfiltered, and honest. That’s what ${t} feels like today. 🥺🌧️`,
      ],
    },
    Hindi: {
      templates: [
        (t) => `कुछ बातें लफ़्ज़ों में बयाँ नहीं होतीं, बस दिल ${t} को महसूस करता है। 🥺❤️`,
        (t) => `${t} सिर्फ़ एक बात नहीं, ये वो अहसास है जो आँखों में नमी छोड़ जाता है। 🌧️🥀`,
        (t) => `वक़्त बीत जाता है पर ${t} से जुड़ी यादें हमेशा दिल के कोने में महकती रहती हैं। ⏳🤍`,
        (t) => `काश वो लम्हा ठहर जाता, जब हम और ${t} एक साथ थे। 🍂💭`,
        (t) => `दिल की ख़ामोशी में भी एक आवाज़ है, जो सिर्फ़ ${t} का नाम पुकारती है। 🌙🕯️`,
        (t) => `ज़िंदगी के हर मोड़ पर कुछ छूट जाता है, पर ${t} का असर कभी कम नहीं होता। 🥀✨`,
        (t) => `मुस्कुराहट के पीछे छुपा दर्द सिर्फ़ वही समझ सकता है जिसने ${t} को जिया हो। 🌊🖤`,
        (t) => `कभी-कभी सिर्फ़ एक याद ही काफ़ी होती है पूरे दिन को नम करने के लिए: ${t}। 🫂🌸`,
        (t) => `सच्चे अहसासों की कोई क़ीमत नहीं होती, जैसे ${t} के साथ बिताए वो अनमोल पल। 🕊️🤍`,
        (t) => `दिल से निकले आँसू और ${t} की दास्तान, दोनों कभी झूठे नहीं होते। 🥺💧`,
      ],
    },
    Assamese: {
      templates: [
        (t) => `কেতিয়াবা কিছুমান অনুভৱ শব্দৰে প্ৰকাশ কৰিব নোৱাৰি, যেনেকৈ ${t} ৰ স্মৃতি। 🥺❤️`,
        (t) => `${t} কেৱল এটা শব্দ নহয়, ই মোৰ বুকুৰ মাজত থকা এটা গভীৰ অনুভৱ। 🌧️🥀`,
        (t) => `সময়বোৰ উৰি গ'ল, কিন্তু ${t} ৰ সেই মিঠা-কেঁহা সুবাস আজিও সজীৱ হৈ আছে। ⏳🤍`,
        (t) => `হৃদয়ৰ কোনোবা এটা কোণত আজিও সংগোপনে সাঁচি ৰখা হৈছে ${t} ক। 🍂💭`,
        (t) => `নিস্তব্ধ ৰাতিবোৰে যেতিয়া কথা কয়, মনটো কেৱল ${t} ৰ কাষলৈকে ধাৱমান হয়। 🌙🕯️`,
        (t) => `কিছুমান হেৰোৱা স্মৃতিয়ে আজিও চকুপানী হৈ নামি আহে: ঠিক ${t} ৰ দৰে। 🥀✨`,
        (t) => `জীৱনৰ আটাইতকৈ মূল্যৱান পাঠ শিকালোঁ ${t} ৰ পৰাই। 🌊🖤`,
        (t) => `চকুলো আৰু হাঁহিৰ মাজৰ এক নিভৃত যাত্ৰা—মোৰ আৰু ${t} ৰ সম্বন্ধ। 🫂🌸`,
        (t) => `হেঁপাহৰ পথাৰখনত আজিও ফুলি আছে ${t} ৰ ৰঙীন আশা। 🕊️🤍`,
        (t) => `মনৰ কথা খুলি ক'বলৈ মানুহ নাথাকে, কিন্তু ${t} এ সদায় মোৰ নীৰৱতা বুজে। 🥺💧`,
      ],
    },
  },
  Romantic: {
    English: {
      templates: [
        (t) => `In a room full of art, my eyes would still search for you and ${t}. 🌹💫`,
        (t) => `You, me, and ${t}—that’s my definition of pure magic. ✨❤️`,
        (t) => `Every love song finally makes sense whenever I think about ${t}. 🎶💌`,
        (t) => `Falling for you wasn't falling at all; it was walking into a house built around ${t}. 🏡🕯️`,
        (t) => `Forever feels too short when it's spent beside you, wrapped in ${t}. ♾️💍`,
        (t) => `My favorite place in the universe will always be right next to ${t}. 🌌🕊️`,
        (t) => `You are the poem I never knew how to write, and ${t} is the rhythm. ✍️🌹`,
        (t) => `Stealing glances, whispered promises, and the quiet sweetness of ${t}. 🍷🌙`,
        (t) => `Two hearts, one shared heartbeat, endlessly grateful for ${t}. 💓✨`,
        (t) => `I looked at you and saw the rest of my life in ${t}. 💍❤️`,
      ],
    },
    Hindi: {
      templates: [
        (t) => `तेरी आँखों में जो नूर है, वो ${t} से भी ज़्यादा ख़ूबसूरत है। 🌹✨`,
        (t) => `इश्क़ का असली मतलब तब समझा, जब ${t} के साथ तुम्हारा नाम जुड़ गया। ❤️💫`,
        (t) => `तुझसे मिलकर लगा जैसे सदियों की प्यास बुझ गई, बस यही है ${t} का जादू। 🎶💌`,
        (t) => `एक तुम, एक मैं, और ये ख़ूबसूरत लम्हा—${t} की दुनिया में हम दोनों! 🏡🕯️`,
        (t) => `दिल की हर धड़कन में बस तुम्हारा ही तराना है, जैसे ${t} का अफ़साना। ♾️💍`,
        (t) => `तेरी मुस्कान पर सदके जाऊँ, जब तू मुस्कुराते हुए ${t} की बात करती है। 🌌🕊️`,
        (t) => `मोहब्बत कोई लफ़्ज़ नहीं, ये वो ख़ुशबू है जो ${t} के साथ हमारे दरमियाँ है। ✍️🌹`,
        (t) => `चाँदनी रात, तुम्हारा हाथ, और ${t} का साथ—ज़िंदगी मुकम्मल हो गई। 🍷🌙`,
        (t) => `हज़ार चेहरे देखे इस जहाँ में, पर दिल सिर्फ़ ${t} और तुम पर आके रुका। 💓✨`,
        (t) => `तू मिले तो हर दर्द दवा बन जाए, जैसे बंजर ज़मीन पर ${t} की बारिश। 💍❤️`,
      ],
    },
    Assamese: {
      templates: [
        (t) => `তোমাৰ দুচকুত দেখা পালোঁ মোৰ সমস্ত পৃথিৱী, আৰু মনত মাথোঁ ${t} ৰ সুবাস। 🌹✨`,
        (t) => `মোৰ প্ৰতিটো কবিতাৰ অন্তৰালত মাথোঁ তোমাৰ নাম আৰু ${t} ৰ মিঠা স্মৃতি। ❤️💫`,
        (t) => `তুমি যেতিয়া কাষত থাকা, ${t} এ যেন এক নতুন ভাষা বিচাৰি পায়। 🎶💌`,
        (t) => `তোমাৰ মৰমৰ পৰশত মোৰ জীৱনৰ বসন্ত নামি আহিল, যেনেকৈ ${t} ৰ বৰষুণ। 🏡🕯️`,
        (t) => `বতাহত উৰি অহা তোমাৰ চুলিতাৰিত আজিও বিচাৰি পাওঁ ${t} ৰ মাদকতা। ♾️💍`,
        (t) => `হৃদয়ৰ গভীৰতাত তোমাক সাঁচি ৰাখিছোঁ, যেনেকৈ মুকুতা সাঁচি ৰাখে সাগৰে: ${t}। 🌌🕊️`,
        (t) => `দুটাহৃদয়, একেটি স্পন্দন—আমাৰ এই প্ৰেমৰ কাহিনীত ${t} সদায় জিলিকি ৰওক। ✍️🌹`,
        (t) => `তোমাৰ এষাৰ মাতত পাহৰি পেলাওঁ সকলো দুখ, ঠিক ${t} ৰ অপাৰ শান্তিৰ দৰে। 🍷🌙`,
        (t) => `মৰম নদীৰ দৰে বৈ যায়, যেতিয়া তুমি কাষত ৰৈ ${t} ৰ কথা কোৱা। 💓✨`,
        (t) => `যুগ যুগ ধৰি তোমাকেই বিচাৰিম, মোৰ প্ৰেমৰ গানত তুমি আৰু ${t}। 💍❤️`,
      ],
    },
  },
  Motivational: {
    English: {
      templates: [
        (t) => `Don't count the days; make the days count. Dominating ${t} today. ⏳🔥`,
        (t) => `Your only limit is the voice in your head telling you ${t} is too hard. Silence it. 🧠💥`,
        (t) => `Success isn't owned; it’s leased, and rent is due every day on ${t}. 📈🔑`,
        (t) => `Fall seven times, stand up eight. Never quitting on ${t}. 🛡️⚡️`,
        (t) => `Small daily improvements over time lead to stunning results with ${t}. 🧗‍♂️🎯`,
        (t) => `Hard work beats talent when talent doesn’t show up for ${t}. 🏋️‍♂️💯`,
        (t) => `Dream big, stay humble, hustle in silence, and let ${t} shock everyone. 🤫🚀`,
        (t) => `The pain of discipline is far less than the pain of regret in ${t}. 🏆🧱`,
        (t) => `You didn't come this far to only come this far. Own your journey in ${t}. 🧭✨`,
        (t) => `One day or day one? You choose your future with ${t}. 🌅💪`,
      ],
    },
    Hindi: {
      templates: [
        (t) => `मंज़िल उन्हीं को मिलती है जिनके सपनों में जान होती है! ${t} में आज जान लगा दो। ⏳🔥`,
        (t) => `अगर इरादे पक्के हों, तो ${t} की हर मुश्किल आसान हो जाती है। 🧠💥`,
        (t) => `हार तब नहीं होती जब आप गिरते हैं, हार तब होती है जब आप ${t} के लिए उठने से मना कर दें। 📈🔑`,
        (t) => `मेहनत इतनी ख़ामोशी से करो कि तुम्हारी ${t} की कामयाबी शोर मचा दे। 🛡️⚡️`,
        (t) => `वक्त से लड़कर जो नसीब बदल दे, इंसान वही जो अपनी ${t} बदल दे! 🧗‍♂️🎯`,
        (t) => `जो आज पसीना बहाएगा, वही कल ${t} की दुनिया पर राज करेगा। 🏋️‍♂️💯`,
        (t) => `खुद पर भरोसा रखो, आज का संघर्ष कल ${t} की सबसे बड़ी जीत बनेगा। 🤫🚀`,
        (t) => `सपने वो नहीं जो सोते हुए देखें, सपने वो हैं जो ${t} के लिए सोने न दें! 🏆🧱`,
        (t) => `शुरुआत हमेशा कठिन होती है, पर ${t} का अंजाम हमेशा खूबसूरत होगा। 🧭✨`,
        (t) => `जिद्दी बनो! जब तक ${t} में सफलता न मिले, रुकना मना है। 🌅💪`,
      ],
    },
    Assamese: {
      templates: [
        (t) => `সপোন সেইটো নহয় যি শুই থাকোঁতে দেখা যায়, সপোন সেইটোহে যিয়ে ${t} ৰ বাবে শুবলৈ নিদিয়ে! ⏳🔥`,
        (t) => `কঠিন পৰিশ্ৰমৰ কোনো বিকল্প নাই, ${t} ত আজি নিজৰ সৰ্বস্ব উজাৰি দিয়া। 🧠💥`,
        (t) => `যদি তুমি উৰিব নোৱাৰা, তেন্তে দৌৰা; যদি দৌৰিব নোৱাৰা, তেন্তে খোজ কাঢ়া—কিন্তু ${t} ত আগবাঢ়া! 📈🔑`,
        (t) => `প্ৰতিটো বিফলতাৰ পিছতে লুকাই থাকে ${t} ৰ এক নতুন জয়যাত্ৰা। 🛡️⚡️`,
        (t) => `ধৈৰ্য্য আৰু একাগ্ৰতা—এই দুটাই তোমাক ${t} ৰ উচ্চতম শৃংগত বহুৱাব। 🧗‍♂️🎯`,
        (t) => `আজিৰ ঘামেই হ'ব কাইলৈৰ গৌৰৱৰ প্ৰতীক, ${t} ৰ বাবে যুঁজ অব্যাহত ৰাখা। 🏋️‍♂️💯`,
        (t) => `লোকৰ কথালৈ কাণ নিদি নিজৰ লক্ষ্যত অবিচল থাকা, ${t} এ তোমাক উত্তৰ দিব। 🤫🚀`,
        (t) => `নিজক চিনি পোৱা, তোমাৰ ভিতৰতে লুকাই আছে ${t} জয় কৰাৰ অসীম শক্তি। 🏆🧱`,
        (t) => `যাত্ৰাটো কঠিন হ'ব পাৰে, কিন্তু ${t} ৰ শেষৰ দৃশ্যটো অতি সুন্দৰ হ'ব। 🧭✨`,
        (t) => `প্ৰতিটো পুৱাই এক নতুন সুযোগ—আজিৰ দিনটো ${t} ৰ নামত সমৰ্পণ কৰা! 🌅💪`,
      ],
    },
  },
  Professional: {} as Record<Language, ToneTemplate>,
  Attitude: {} as Record<Language, ToneTemplate>,
  Inspirational: {} as Record<Language, ToneTemplate>,
};

// Fill out remaining tones with rich, well-crafted templates
const completeToneData = () => {
  // Professional
  CAPTION_GENERATOR_DATA.Professional = {
    English: {
      templates: [
        (t) => `Strategic execution and measurable impact: Our latest perspective on ${t}. 📊💼`,
        (t) => `Consistency, quality, and rigorous standards define how we approach ${t}. 🏛️📈`,
        (t) => `Behind every breakthrough in ${t} lies structured research and disciplined execution. 🔍📑`,
        (t) => `Streamlining workflows and maximizing long-term efficiency through ${t}. ⚙️🤝`,
        (t) => `Excited to share recent milestones and data-driven insights surrounding ${t}. 💡📌`,
        (t) => `How modern industry leaders are recalibrating their approach toward ${t}. 🌐🎯`,
        (t) => `Delivering excellence is a standard, not an option. Case in point: ${t}. 🏢✨`,
        (t) => `Collaborative problem-solving: Navigating the modern complexities of ${t}. 👥🤝`,
        (t) => `Focusing on long-term sustainability and sustainable scalability in ${t}. 🌿📊`,
        (t) => `Refining the playbook: Key takeaways from our recent work on ${t}. 📘♟️`,
      ],
    },
    Hindi: {
      templates: [
        (t) => `${t} में रणनीतिक सोच और बेहतर नतीजों के साथ एक नई शुरुआत। 📊💼`,
        (t) => `गुणवत्ता और अनुशासन ही हमें ${t} के क्षेत्र में आगे बढ़ने की प्रेरणा देते हैं। 🏛️📈`,
        (t) => `बिज़नेस और नवाचार का सही तालमेल: ${t} के ज़रिये नए समाधान खोजना। 🔍📑`,
        (t) => `सफलता सिर्फ़ एक लक्ष्य नहीं, बल्कि ${t} के प्रति निरंतर प्रतिबद्धता की यात्रा है। ⚙️🤝`,
        (t) => `कार्यकुशलता और स्पष्ट विज़न के साथ ${t} में बेहतरीन परिणाम हासिल करना। 💡📌`,
        (t) => `बाज़ार की ज़रूरतों को समझना और ${t} के माध्यम से मूल्य प्रदान करना। 🌐🎯`,
        (t) => `पेशेवर दृष्टिकोण और सही तकनीक के साथ ${t} का सफल क्रियान्वयन। 🏢✨`,
        (t) => `सकारात्मक बदलाव और टीम वर्क: ${t} में नए मील के पत्थर स्थापित करते हुए। 👥🤝`,
        (t) => `दीर्घकालिक विकास और मजबूत नींव: ${t} के लिए हमारा रोडमैप। 🌿📊`,
        (t) => `अनुभव और विशेषज्ञता के आधार पर ${t} में सर्वश्रेष्ठ सेवाएं देना हमारी प्राथमिकता है। 📘♟️`,
      ],
    },
    Assamese: {
      templates: [
        (t) => `দক্ষতা আৰু শৃংখলাবদ্ধ পৰিকল্পনাৰে ${t} ৰ দিশত এক নতুন পদক্ষেপ। 📊💼`,
        (t) => `গুণগত মান আৰু স্পষ্ট দৃষ্টিভংগীয়ে আমাক ${t} ত আগবাঢ়িবলৈ শক্তি যোগায়। 🏛️📈`,
        (t) => `উদ্ভাৱন আৰু পেশাদাৰী সেৱাৰ অপূৰ্ব মিলন: ${t} ৰ সফল ৰূপায়ণ। 🔍📑`,
        (t) => `প্ৰতিটো কামতে নিষ্ঠা আৰু পৰিশ্ৰমৰ প্ৰতিফলন ঘটাই ${t} ত সফলতা অৰ্জন। ⚙️🤝`,
        (t) => `দীৰ্ঘম্যাদী উন্নয়ন আৰু সমাজৰ প্ৰয়োজনীয়তাক লক্ষ্য কৰি ${t} ৰ কাৰ্যসূচী। 💡📌`,
        (t) => `নতুন প্ৰযুক্তি আৰু সঠিক নেতৃত্বৰে ${t} ক আগুৱাই লৈ যোৱাৰ প্ৰয়াস। 🌐🎯`,
        (t) => `কৰ্মস্পৃহা আৰু পেছাদাৰী সততাই আমাৰ ${t} ৰ মূল চালিকা শক্তি। 🏢✨`,
        (t) => `সহযোগিতামূলক মনোভাব আৰু লক্ষ্যৰ স্থিৰতাই ${t} ত সুফল আনে। 👥🤝`,
        (t) => `উচ্চমানৰ সেৱা আৰু বিশ্বস্ততা বজাই ৰাখি ${t} ত এক নতুন মাত্ৰা যোগ। 🌿📊`,
        (t) => `ভৱিষ্যতৰ বাবে প্ৰস্তুত: ${t} ৰ শেহতীয়া অগ্ৰগতি আৰু পৰিকল্পনা। 📘♟️`,
      ],
    },
  };

  // Attitude
  CAPTION_GENERATOR_DATA.Attitude = {
    English: {
      templates: [
        (t) => `I’m not a backup plan, and definitely not a second choice in ${t}. 👑🔥`,
        (t) => `They talk behind my back because they’re in the perfect position to watch me conquer ${t}. 💅🏼⚡️`,
        (t) => `Classy on the outside, ruthless about ${t} on the inside. 🖤🍸`,
        (t) => `My circle is small because I value quality, especially when it comes to ${t}. ⭕️💎`,
        (t) => `Don't study me, you won’t graduate. Fully tuned into ${t}. 📚🚫`,
        (t) => `Born to express, not to impress. Living ${t} on my own terms. 🐅✨`,
        (t) => `Too busy building an empire around ${t} to care about opinions. 🏰🛡️`,
        (t) => `Silence is the best reply to fools, and victory in ${t} is the ultimate payback. 🤐🏆`,
        (t) => `You want to sit at my table? Bring respect and respect for ${t}. 🍽️♟️`,
        (t) => `Unapologetic. Unmatched. Unstoppable when focused on ${t}. ⚡️👑`,
      ],
    },
    Hindi: {
      templates: [
        (t) => `हमसे मुक़ाबला करने की सोचना भी मत, ${t} में हमारा रुतबा अलग है! 👑🔥`,
        (t) => `पीठ पीछे वही बोलते हैं जिनकी औकात हमारे सामने ${t} पर बात करने की नहीं होती। 💅🏼⚡️`,
        (t) => `शौक हमारे ऊँचे हैं और ${t} के प्रति जुनून सबसे अलग! 🖤🍸`,
        (t) => `हमें हराने का ख्वाब देखने वालों, पहले ${t} में हमारे जैसा पसीना बहा के दिखाओ। ⭕️💎`,
        (t) => `हमारी खामोशी को कमजोरी मत समझना, जब ${t} में उतरते हैं तो तूफान लाते हैं। 🐅✨`,
        (t) => `तेवर तो हम वक़्त आने पर दिखाएंगे, शहर तुम खरीदो पर राज ${t} से हम करेंगे। 🏰🛡️`,
        (t) => `भीड़ का हिस्सा बनना हमारी फितरत नहीं, हम जहाँ खड़े होते हैं ${t} की लाइन वहीं से शुरू होती है। 🤐🏆`,
        (t) => `अंदाज़ अपना अलग है, जलने वाले जलते रहें और हम ${t} में छाते रहें। 🍽️♟️`,
        (t) => `हमसे बराबरी करनी है तो अपनी सोच और ${t} का लेवल बढ़ाओ। ⚡️👑`,
        (t) => `वक़्त खराब हो सकता है, लेकिन हमारा ${t} का ऐटिट्यूड हमेशा टॉप पर रहता है। 🦁🔥`,
      ],
    },
    Assamese: {
      templates: [
        (t) => `মোৰ লগত তুলনা কৰিবলৈ নাযাবা, ${t} ত মোৰ স্থান সদায় সুকীয়া! 👑🔥`,
        (t) => `যিসকলে পিছফালে সমালোচনা কৰে, তেওঁলোকক ${t} ৰ সফলতাই উপযুক্ত উত্তৰ দিব। 💅🏼⚡️`,
        (t) => `মই আনৰ পছন্দ অনুসৰি সলনি নহওঁ, ${t} ত মোৰ নিজৰ নীতি আছে! 🖤🍸`,
        (t) => `শান্ত হৈ থকা মানেই দুৰ্বল নহয়, ${t} ত যেতিয়া নামিম সকলোৱে বুজি পাব। ⭕️💎`,
        (t) => `আনক আকৰ্ষিত কৰাৰ কোনো প্ৰয়োজন নাই, ${t} ত নিজৰ স্বকীয়তাই যথেষ্ট। 🐅✨`,
        (t) => `সিংহ সদায় অকলেই চিকাৰ কৰে, ঠিক তেনেকৈ ${t} ত মই নিজৰ পথত অকলশৰীয়া। 🏰🛡️`,
        (t) => `মোৰ সাহস আৰু ধৈৰ্য্যক পৰীক্ষা নকৰিবা, ${t} ৰ যুদ্ধত মই সদায় অপৰাজেয়। 🤐🏆`,
        (t) => `ৰজা হ'বলৈ মুকুটৰ প্ৰয়োজন নাই, ${t} ৰ কামতেই ৰাজকীয় ব্যক্তিত্ব ফুটি উঠে। 🍽️♟️`,
        (t) => `যিয়ে যি কয় কওক, মোৰ লক্ষ্য সদায় ${t} ৰ উচ্চ শিখৰত! ⚡️👑`,
        (t) => `স্বাভিমানত কোনো আঘাত সহ্য নকৰোঁ, বিশেষকৈ যেতিয়া কথাটো ${t} ৰ হয়। 🦁🔥`,
      ],
    },
  };

  // Inspirational
  CAPTION_GENERATOR_DATA.Inspirational = {
    English: {
      templates: [
        (t) => `Plant seeds today that will bloom into extraordinary forests with ${t}. 🌱✨`,
        (t) => `Every master was once a beginner. Trust the slow, sacred evolution of ${t}. 🦋🕊️`,
        (t) => `Be the energy you want to attract into the world, starting through ${t}. ☀️💫`,
        (t) => `Your story isn't over yet; this chapter about ${t} is where the magic begins. 📖🕯️`,
        (t) => `Light up the darkness by sharing your genuine passion for ${t}. 💡🌌`,
        (t) => `Grateful for where I’m at, excited for where ${t} is taking me next. 🙏🌈`,
        (t) => `The universe rewards courageous souls who stay true to ${t}. 🪐🗝️`,
        (t) => `Breathe in hope, exhale doubt, and pour your soul into ${t}. 🧘‍♂️🌸`,
        (t) => `You are capable of far more than your fears will ever allow you to believe regarding ${t}. 🏔️🦅`,
        (t) => `Let kindness be your compass and passion for ${t} be your fuel. 🧭❤️`,
      ],
    },
    Hindi: {
      templates: [
        (t) => `उम्मीद की एक किरण ही काफी है, ${t} के ज़रिए एक नई सुबह लाने के लिए। 🌱✨`,
        (t) => `हर बड़ा सफर एक छोटे कदम से शुरू होता है, आज वो कदम ${t} की ओर बढ़ाएं। 🦋🕊️`,
        (t) => `जब मन में सच्चाई और लगन हो, तो ${t} की हर राह रोशन हो जाती है। ☀️💫`,
        (t) => `विश्वास वह ताकत है जो पत्थर में भी जान फूंक दे, और ${t} को सफल बना दे। 📖🕯️`,
        (t) => `अपने सपनों को पंख दो और ${t} के आसमान में बेखौफ उड़ना सीखो। 💡🌌`,
        (t) => `शुक्रगुज़ार रहो हर उस पल के लिए जिसने तुम्हें ${t} के काबिल बनाया। 🙏🌈`,
        (t) => `जिंदगी में हमेशा कुछ नया सीखने की प्यास ही हमें ${t} में महान बनाती है। 🪐🗝️`,
        (t) => `अंधेरे से मत डरो, क्योंकि सितारे सिर्फ़ अंधेरे में ही चमकते हैं—जैसे तुम्हारा ${t}। 🧘‍♂️🌸`,
        (t) => `सच्चा सुख दूसरों को प्रेरित करने और ${t} से समाज में अच्छाई लाने में है। 🏔️🦅`,
        (t) => `खुद को पहचानो, तुम वो दीपक हो जो ${t} की रौशनी से सबको प्रकाशित कर सकता है। 🧭❤️`,
      ],
    },
    Assamese: {
      templates: [
        (t) => `আশাৰ এটি সৰু কিৰণেই যথেষ্ট, ${t} ৰ জৰিয়তে জীৱনক নতুন ৰূপ দিবলৈ। 🌱✨`,
        (t) => `ধৈৰ্য্য আৰু সংগ্ৰামেই সৃষ্টি কৰে এক সুন্দৰ ভৱিষ্যত, যাৰ আৰম্ভণি ${t} ৰ পৰা। 🦋🕊️`,
        (t) => `নিজৰ অন্তৰত জ্বলি থকা বিশ্বাসৰ চাকিটি নুনুমুৱাবা, ${t} এ বাট দেখুৱাব। ☀️💫`,
        (t) => `প্ৰকৃতিৰ দৰেই শান্ত হোৱা আৰু নদীৰ দৰে বৈ যোৱা, ${t} ৰ সন্ধানত। 📖🕯️`,
        (t) => `জীৱনটো এখন উকা কাগজ, তাত ${t} ৰ অপূৰ্ব ৰঙেৰে ছবি আঁকা। 💡🌌`,
        (t) => `ঈশ্বৰৰ সৃষ্টিত সকলোৰে এক উদ্দেশ্য আছে, মোৰ উদ্দেশ্য হৈছে ${t} ক উজলাই তোলা। 🙏🌈`,
        (t) => `প্ৰতিটো পুৱাই কঢ়িয়াই আনে এক নতুন সম্ভাৱনা, ${t} ত আস্থা ৰাখা। 🪐🗝️`,
        (t) => `আনক সহায় কৰা আৰু প্ৰেৰণা যোগোৱাতেই জীৱনৰ সাৰ্থকতা, ঠিক ${t} ৰ দৰে। 🧘‍♂️🌸`,
        (t) => `নিজৰ সপোনক কেতিয়াও মৰহি যাবলৈ নিদিবা, ${t} ত বিশ্বাসেই আটাইতকৈ ডাঙৰ শক্তি। 🏔️🦅`,
        (t) => `মৰম আৰু মানৱতাৰে পৃথিৱীখন জিনিব পাৰি, এই পথত সদায় সংগী হওক ${t}। 🧭❤️`,
      ],
    },
  };
};

completeToneData();

export function generateCaptions(
  topic: string,
  tone: CaptionTone,
  language: Language
): string[] {
  const cleanTopic = topic.trim() || 'Instagram Life';
  const toneData = CAPTION_GENERATOR_DATA[tone]?.[language] ||
    CAPTION_GENERATOR_DATA[tone]?.['English'];

  if (!toneData || !toneData.templates) {
    return Array.from({ length: 10 }).map(
      (_, i) => `Capturing ${cleanTopic} ✨ Idea #${i + 1}`
    );
  }

  // Generate all 10 caption ideas
  return toneData.templates.map((tpl) => tpl(cleanTopic));
}
