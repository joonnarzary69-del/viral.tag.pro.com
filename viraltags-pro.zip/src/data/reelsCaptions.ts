import { Language } from './categories';

export type ReelsCategory =
  | 'Gaming'
  | 'Comedy'
  | 'Dance'
  | 'Editing'
  | 'Motivation'
  | 'Fashion'
  | 'Lifestyle';

export const REELS_CATEGORIES: ReelsCategory[] = [
  'Gaming',
  'Comedy',
  'Dance',
  'Editing',
  'Motivation',
  'Fashion',
  'Lifestyle',
];

export interface ReelIdea {
  hook: string;
  caption: string;
  audioPrompt: string;
  hashtags: string[];
}

export function generateReelsIdeas(
  category: ReelsCategory,
  topic: string,
  language: Language
): ReelIdea[] {
  const clean = topic.trim() || category;

  if (language === 'Hindi') {
    return [
      {
        hook: '👀 अंत तक देखें वरना पछताएंगे...',
        caption: `जब आप पहली बार ${clean} आज़माते हैं और ऐसा कुछ हो जाता है! 😂👇 अपने उस दोस्त को टैग करें जो बिल्कुल ऐसा ही करता है!`,
        audioPrompt: 'Trending Desi Beat / Viral Dialogue Audio',
        hashtags: ['#reelsindia', '#viralreels', `#${category.toLowerCase()}`, '#explorepage', '#trendingaudio', '#desireels'],
      },
      {
        hook: 'POV: जब ${clean} आपका असली जुनून बन जाए! 🔥',
        caption: `किसी ने नहीं सोचा था कि ${clean} से ऐसा जादू हो सकता है। मेहनत कभी बेकार नहीं जाती! ❤️`,
        audioPrompt: 'Slowed + Reverb Emotional Phonk / Lo-fi',
        hashtags: ['#reelitfeelit', '#indiancreators', '#reelsinstagram', '#viralvideo', '#explore'],
      },
      {
        hook: '⚠️ इस वीडियो को लूप पर देखने के लिए तैयार हो जाएं! 🔁',
        caption: `${clean} का यह तरीका 99% लोग नहीं जानते। सेव करें और बाद में खुद ट्राई करें! 📌`,
        audioPrompt: 'Fast Tempo Hook / Trending Bass drop',
        hashtags: ['#foryoupage', '#reelkarofeelkaro', '#trendingreels', '#viralhindi', '#reelsviral'],
      },
      {
        hook: 'क्या आपको भी ${clean} से इतना ही प्यार है? 😍',
        caption: `दिन भर की थकान के बाद जब ${clean} का मौका मिले तो दिल खुश हो जाता है। आप क्या कहते हैं? 👇`,
        audioPrompt: 'Soft Acoustic Guitar / Peaceful Melody',
        hashtags: ['#indiagram', '#reelsdaily', '#contentcreatorindia', '#instareels', '#desivibes'],
      },
      {
        hook: '3 सेकंड में जानिए ${clean} की सबसे बड़ी सच्चाई! ⚡️',
        caption: `अगर आप भी इसमें नए हैं, तो यह गलती कभी मत करना। शेयर करें अपने ग्रुप में! ↗️`,
        audioPrompt: 'Curiosity Sparking Sound / Dramatic beat',
        hashtags: ['#gyanreels', '#viralindia', '#foryou', '#trendingnow', '#reelvideo'],
      },
    ];
  }

  if (language === 'Assamese') {
    return [
      {
        hook: '👀 শেষলৈকে চাওক, শেষৰ টুইষ্টটো বৰ আমোদজনক...',
        caption: `${clean} ৰ এই কাণ্ডটো দেখিলে আপুনিও আচৰিত হ'ব! 😂 তলত আপোনাৰ মতামত জনাওক আৰু Share কৰক! ↗️`,
        audioPrompt: 'Trending Bihu Modern Fusion / Viral Axom Audio',
        hashtags: ['#assamreels', '#axomreels', '#guwahatireels', `#${category.toLowerCase()}`, '#exploreassam', '#viralaxom'],
      },
      {
        hook: 'POV: যেতিয়া ${clean} ত আপুনি নিজৰ শ্ৰেষ্ঠত্ব উজাৰি দিয়ে! 🔥',
        caption: `সপোন সদায় ডাঙৰ হ'ব লাগে, আৰু ${clean} ৰ জৰিয়তে তাক বাস্তৱলৈ আনিব পাৰি! ❤️`,
        audioPrompt: 'Emotional flute / Assamese Lo-Fi Melody',
        hashtags: ['#awesomeassam', '#axomiyareels', '#northeastindia', '#reelsinstagram', '#explore'],
      },
      {
        hook: '🔁 Loop ত চাওক, এবাৰ চাই মন নভৰিব!',
        caption: `${clean} ৰ এই সহজ উপায়টো এবাৰ চেষ্টা কৰি চাওকচোন। এই পোষ্টটো Save কৰি ৰাখক! 📌`,
        audioPrompt: 'Fast Rhythm Hook / Energetic Drop',
        hashtags: ['#assamesevideo', '#axomcreators', '#viralreels', '#reelitfeelit', '#trendingaxom'],
      },
      {
        hook: 'আপোনাৰো ${clean} ৰ প্ৰতি এনেকুৱা হেঁপাহ আছে নেকি? 😍',
        caption: `মনৰ আনন্দৰ বাবে কৰা কামবোৰৰ মজাই সুকীয়া। কমেন্টত জনাবলৈ নাপাহৰিব! 👇`,
        audioPrompt: 'Soft Instrumental / Acoustic Axomiya Tone',
        hashtags: ['#assamlove', '#axomreelsdaily', '#guwahatipeople', '#northeastcreators', '#instareels'],
      },
      {
        hook: '৩ ছেকেণ্ডত শিকক ${clean} ৰ এক অনন্য কৌশল! ⚡️',
        caption: `যিসকলে নতুনকৈ শিকিছে তেওঁলোকৰ বাবে অতি প্ৰয়োজনীয়। আপোনাৰ বন্ধুবৰ্গলৈ পঠিয়াই দিয়ক! 🚀`,
        audioPrompt: 'Dramatic Background Beat / Curiosity Audio',
        hashtags: ['#assameducation', '#viralassam', '#axompost', '#trendingreels', '#explorepage'],
      },
    ];
  }

  // English
  return [
    {
      hook: `👀 Watch until the end, you won't see this coming...`,
      caption: `Attempting ${clean} and things didn't go as planned at all! 😂 Tag a friend who definitely needs to see this.`,
      audioPrompt: 'High Energy Beat Drop / Viral TikTok Audio',
      hashtags: ['#reels', '#reelsinstagram', '#viralreels', `#${category.toLowerCase()}`, '#trendingreels', '#foryoupage'],
    },
    {
      hook: `POV: You finally unlocked the secret to ${clean} 🔥`,
      caption: `Stop overcomplicating it. When you focus on simplicity and consistency with ${clean}, everything levels up. Save this reminder! 📌`,
      audioPrompt: 'Lo-Fi Chill Hop / Nostalgic Synthwave',
      hashtags: ['#reelitfeelit', '#explorepage', '#contentcreator', '#aestheticreels', '#viralvideo'],
    },
    {
      hook: `🔁 Put this on a loop because the detail is unreal!`,
      caption: `Breaking down ${clean} step-by-step. Double tap if you learned something new today! ❤️`,
      audioPrompt: 'Seamless Loop Audio / Trending Rhythmic Beat',
      hashtags: ['#reelsvideo', '#trendingaudio', '#instareels', '#dailyreels', '#foryou'],
    },
    {
      hook: `If you love ${clean}, this one is strictly for you ✨`,
      caption: `Nothing hits quite like diving deep into ${clean}. Drop a ❤️ in the comments if you agree!`,
      audioPrompt: 'Uplifting Ambient / Cinematic Strings',
      hashtags: ['#creatorreels', '#reelsofinstagram', '#viralreels', '#explore', '#trendingnow'],
    },
    {
      hook: `Stop scrolling! ✋ The 3 rules of ${clean} you need to know:`,
      caption: `1. Start before you're ready.\n2. Focus on value over vanity.\n3. Keep your loops tight.\n\nShare this with another creator! ↗️`,
      audioPrompt: 'Punchy Curiosity Audio / Upbeat Modern Hook',
      hashtags: ['#reeltips', '#creatorgrowth', '#instagramreels', '#reelsdaily', '#viraltips'],
    },
  ];
}
