import { CategoryKey } from './categories';

export type BioStyle =
  | 'Aesthetic & Clean'
  | 'Creator & Influencer'
  | 'Business & Coach'
  | 'Punchy & Attitude'
  | 'Poetic & Mindful';

export const BIO_STYLES: BioStyle[] = [
  'Aesthetic & Clean',
  'Creator & Influencer',
  'Business & Coach',
  'Punchy & Attitude',
  'Poetic & Mindful',
];

export interface BioIdea {
  text: string;
  charCount: number;
  style: BioStyle;
}

export function generateBioIdeas(
  name: string,
  category: CategoryKey,
  style: BioStyle,
  includeEmojis: boolean
): BioIdea[] {
  const brand = name.trim() || 'Creator';

  const rawPresets: Record<BioStyle, string[][]> = {
    'Aesthetic & Clean': [
      [
        includeEmojis ? `✨ ${brand}` : brand,
        `curating moments in ${category.toLowerCase()}`,
        'simplicity over noise',
        includeEmojis ? '💌 inquiries below' : 'inquiries below',
      ],
      [
        includeEmojis ? `🌿 ${brand} | aesthetic journal` : `${brand} | aesthetic journal`,
        `documenting art & ${category.toLowerCase()}`,
        'soft living & intentional vibes',
        includeEmojis ? '👇 explore more' : 'explore more',
      ],
      [
        brand,
        includeEmojis ? `☕️ daily ${category.toLowerCase()} diaries` : `daily ${category.toLowerCase()} diaries`,
        'finding beauty in the ordinary',
        'say hello below',
      ],
      [
        includeEmojis ? `🌙 ${brand}` : brand,
        `visual thoughts · ${category.toLowerCase()}`,
        'less perfection, more real life',
        includeEmojis ? '🔗 links & prints' : 'links & prints',
      ],
    ],
    'Creator & Influencer': [
      [
        includeEmojis ? `⚡️ ${brand} | Digital Creator` : `${brand} | Digital Creator`,
        includeEmojis ? `🎬 High-energy ${category.toLowerCase()} content` : `High-energy ${category.toLowerCase()} content`,
        'Daily Reels & Community updates',
        includeEmojis ? '📩 Collabs: DM or email below' : 'Collabs: DM or email below',
      ],
      [
        brand,
        includeEmojis ? `🔥 Helping you level up in ${category.toLowerCase()}` : `Helping you level up in ${category.toLowerCase()}`,
        '100k+ community across platforms',
        includeEmojis ? '👇 Watch my latest series' : 'Watch my latest series',
      ],
      [
        includeEmojis ? `🎯 ${brand}` : brand,
        `Your daily dose of ${category.toLowerCase()} inspiration`,
        'New drops every Tuesday & Friday',
        includeEmojis ? '✨ Tap link to join the squad' : 'Tap link to join the squad',
      ],
      [
        brand,
        includeEmojis ? `🚀 Exploring the best in ${category.toLowerCase()}` : `Exploring the best in ${category.toLowerCase()}`,
        'Passionate storyteller & filmmaker',
        includeEmojis ? '📲 Work with me below' : 'Work with me below',
      ],
    ],
    'Business & Coach': [
      [
        brand,
        includeEmojis ? `💼 ${category} Strategist & Consultant` : `${category} Strategist & Consultant`,
        'Helping 100+ brands scale sustainably',
        includeEmojis ? '📈 Book your strategy audit below' : 'Book your strategy audit below',
      ],
      [
        includeEmojis ? `🏆 ${brand} Official` : `${brand} Official`,
        `Premium solutions for ${category.toLowerCase()} enthusiasts`,
        'Trusted by creators worldwide',
        includeEmojis ? '👇 Shop the collection / Get started' : 'Shop the collection / Get started',
      ],
      [
        brand,
        includeEmojis ? `💡 Actionable advice for ${category.toLowerCase()}` : `Actionable advice for ${category.toLowerCase()}`,
        'Turn your passion into consistent revenue',
        includeEmojis ? '🎁 Free starter guide in bio' : 'Free starter guide in bio',
      ],
      [
        includeEmojis ? `🤝 Welcome to ${brand}` : `Welcome to ${brand}`,
        `Your partner in modern ${category.toLowerCase()}`,
        'Guaranteed results & client focus',
        includeEmojis ? '🔗 Learn more at the link below' : 'Learn more at the link below',
      ],
    ],
    'Punchy & Attitude': [
      [
        includeEmojis ? `👑 ${brand}` : brand,
        `Mastering ${category.toLowerCase()} on my own rules`,
        'Not here to be average',
        includeEmojis ? '⚡️ Watch me win or join in' : 'Watch me win or join in',
      ],
      [
        brand,
        includeEmojis ? `🐆 Built different in ${category.toLowerCase()}` : `Built different in ${category.toLowerCase()}`,
        'Zero excuses · Pure execution',
        includeEmojis ? '🔥 Stay tuned below' : 'Stay tuned below',
      ],
      [
        includeEmojis ? `🖤 ${brand}` : brand,
        `Underestimate me in ${category.toLowerCase()}? Watch.`,
        'Silence is loud, results are louder',
        'Link below',
      ],
      [
        brand,
        includeEmojis ? `💎 Living unapologetically` : `Living unapologetically`,
        `Obsessed with ${category.toLowerCase()}`,
        includeEmojis ? '🕶️ Check the vibe below' : 'Check the vibe below',
      ],
    ],
    'Poetic & Mindful': [
      [
        includeEmojis ? `🕊️ ${brand}` : brand,
        `Seeking stillness in a noisy world`,
        `A heart devoted to ${category.toLowerCase()}`,
        includeEmojis ? '🌸 Read my reflections below' : 'Read my reflections below',
      ],
      [
        brand,
        includeEmojis ? `🕯️ Breathing life into ${category.toLowerCase()}` : `Breathing life into ${category.toLowerCase()}`,
        'Words, warmth, and honest growth',
        'Grateful for every season',
      ],
      [
        includeEmojis ? `🌙 ${brand}` : brand,
        `Chasing sunsets & deep conversations`,
        `Exploring the soul of ${category.toLowerCase()}`,
        includeEmojis ? '✨ Welcome to my safe space' : 'Welcome to my safe space',
      ],
      [
        brand,
        'Rooted in gratitude, growing with grace',
        `Daily notes on ${category.toLowerCase()}`,
        includeEmojis ? '🌿 Join the newsletter below' : 'Join the newsletter below',
      ],
    ],
  };

  const selectedList = rawPresets[style] || rawPresets['Aesthetic & Clean'];

  return selectedList.map((lines) => {
    const text = lines.join('\n');
    return {
      text,
      charCount: text.length,
      style,
    };
  });
}
