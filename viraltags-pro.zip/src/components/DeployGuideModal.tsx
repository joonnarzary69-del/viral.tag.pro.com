import React, { useState } from 'react';
import { X, Github, Globe, Terminal, Copy, Check } from 'lucide-react';
import { copyToClipboard } from '../utils/export';

interface DeployGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeployGuideModal: React.FC<DeployGuideModalProps> = ({ isOpen, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = async (code: string, key: string) => {
    await copyToClipboard(code);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const gitCommands = `# 1. Initialize git repository
git init
git add .
git commit -m "Initial commit of ViralTags Pro"

# 2. Build production assets
npm run build

# 3. Create a new GitHub repo and push
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/viraltags-pro.git
git push -u origin main`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-700/80 rounded-2xl p-6 sm:p-8 text-slate-200 shadow-2xl"
        role="dialog"
        aria-labelledby="deploy-title"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center shadow-lg">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 id="deploy-title" className="text-2xl font-bold text-white tracking-tight">
              Free Hosting &amp; GitHub Pages Guide
            </h2>
            <p className="text-xs text-purple-400">
              Publish ViralTags Pro online in 5 minutes with zero hosting cost
            </p>
          </div>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <section className="space-y-3">
            <h3 className="font-semibold text-white flex items-center gap-2 text-sm sm:text-base">
              <Github className="w-4 h-4 text-purple-400" />
              Option 1: Deploy on GitHub Pages (100% Free)
            </h3>
            <ol className="list-decimal pl-5 space-y-2 text-slate-300">
              <li>
                Create a free account on <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-pink-400 underline">GitHub.com</a> and create a new public repository named <code className="bg-slate-800 px-1 py-0.5 rounded text-purple-300">viraltags-pro</code>.
              </li>
              <li>
                Push your project files to the repository using the terminal commands below:
              </li>
            </ol>

            <div className="relative mt-2 p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300">
              <button
                onClick={() => handleCopy(gitCommands, 'git')}
                className="absolute top-2.5 right-2.5 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 transition-colors"
                title="Copy command"
              >
                {copiedKey === 'git' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[10px]">{copiedKey === 'git' ? 'Copied' : 'Copy'}</span>
              </button>
              <pre className="overflow-x-auto whitespace-pre-wrap">{gitCommands}</pre>
            </div>

            <ol start={3} className="list-decimal pl-5 space-y-1 text-slate-300">
              <li>Go to your repository <strong>Settings &gt; Pages</strong> on GitHub.</li>
              <li>Under <strong>Build and deployment &gt; Source</strong>, select <strong>GitHub Actions</strong> or select deploy from the <code className="bg-slate-800 px-1 py-0.5 rounded text-purple-300">dist</code> branch.</li>
              <li>Within 60 seconds, your site is live at: <code className="bg-slate-800 px-1 py-0.5 rounded text-pink-300">https://yourusername.github.io/viraltags-pro/</code>.</li>
            </ol>
          </section>

          <section className="space-y-3 pt-2 border-t border-slate-800">
            <h3 className="font-semibold text-white flex items-center gap-2 text-sm sm:text-base">
              <Terminal className="w-4 h-4 text-pink-400" />
              Option 2: 1-Click Deploy on Vercel or Netlify
            </h3>
            <p className="text-slate-300">
              Because ViralTags Pro is built as a lightning-fast Vite React single-page application, you can also deploy it directly by dragging the <code className="bg-slate-800 px-1 py-0.5 rounded text-purple-300">dist/</code> folder into <a href="https://netlify.com" target="_blank" rel="noopener noreferrer" className="text-pink-400 underline">Netlify Drop</a> or connecting your GitHub repo on <a href="https://vercel.com" target="_blank" rel="noopener noreferrer" className="text-purple-400 underline">Vercel</a>.
            </p>
          </section>
        </div>

        <div className="mt-8 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-sm transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
