import React, { useState } from 'react';
import { Info, ExternalLink } from 'lucide-react';

interface AdSenseSlotProps {
  format?: 'leaderboard' | 'rectangle' | 'in-feed';
  slotName?: string;
  className?: string;
}

export const AdSenseSlot: React.FC<AdSenseSlotProps> = ({
  format = 'leaderboard',
  slotName = 'General Responsive Slot',
  className = '',
}) => {
  const [showConfigHelp, setShowConfigHelp] = useState(false);

  // Height and dimensions depending on format
  const getDimensionClass = () => {
    switch (format) {
      case 'leaderboard':
        return 'w-full max-w-[728px] min-h-[90px] h-auto py-3';
      case 'rectangle':
        return 'w-full max-w-[336px] min-h-[280px] h-auto p-4';
      case 'in-feed':
        return 'w-full min-h-[100px] h-auto py-3 px-4';
      default:
        return 'w-full min-h-[90px]';
    }
  };

  return (
    <aside
      aria-label="Advertisement area"
      className={`mx-auto my-6 flex flex-col items-center justify-center ${className}`}
    >
      <div className="flex items-center justify-between w-full max-w-[728px] px-2 mb-1.5 text-[11px] text-slate-400">
        <span className="font-medium tracking-wide uppercase">Advertisement</span>
        <button
          type="button"
          onClick={() => setShowConfigHelp(!showConfigHelp)}
          className="flex items-center gap-1 hover:text-purple-400 transition-colors focus:outline-none"
          title="Google AdSense Setup Guide"
        >
          <Info className="w-3.5 h-3.5" />
          <span>AdSense Setup</span>
        </button>
      </div>

      {showConfigHelp && (
        <div className="w-full max-w-[728px] mb-3 p-3 text-xs bg-slate-900/90 border border-purple-500/30 rounded-lg text-slate-300">
          <p className="font-semibold text-purple-300 mb-1">
            Google AdSense Integration Ready:
          </p>
          <p className="mb-2">
            This space is reserved for Google AdSense. Once your AdSense application is approved:
          </p>
          <ol className="list-decimal pl-4 space-y-1 text-slate-300">
            <li>Place your AdSense script in <code className="bg-slate-800 px-1 py-0.5 rounded text-pink-300">&lt;head&gt;</code> of index.html.</li>
            <li>In <code className="bg-slate-800 px-1 py-0.5 rounded text-pink-300">AdSenseSlot.tsx</code>, replace this placeholder with your approved <code className="bg-slate-800 px-1 py-0.5 rounded text-pink-300">&lt;ins class="adsbygoogle" ...&gt;</code> snippet.</li>
            <li>No fake publisher IDs are hardcoded to ensure immediate compliance.</li>
          </ol>
        </div>
      )}

      {/* Ad placement container */}
      <div
        className={`${getDimensionClass()} border border-dashed border-slate-700/60 bg-slate-950/40 rounded-xl flex flex-col items-center justify-center text-center`}
      >
        <div className="text-slate-400 text-xs flex flex-col items-center gap-1">
          <span className="text-slate-300 font-medium">Ad Slot: {slotName}</span>
          <span className="text-[11px] text-slate-400">
            {format === 'leaderboard' && 'Recommended: 728×90 Leaderboard / 320×50 Mobile Banner'}
            {format === 'rectangle' && 'Recommended: 300×250 Medium Rectangle / 336×280'}
            {format === 'in-feed' && 'Responsive Native In-Feed Unit'}
          </span>
        </div>
      </div>
    </aside>
  );
};
