import React from 'react';
import {
  Hash,
  MessageSquare,
  FileText,
  Tag,
  UserCheck,
  Video,
  ArrowRight,
} from 'lucide-react';

interface ToolCardsGridProps {
  onSelectTool: (id: string) => void;
}

interface ToolCard {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  accentColor: string;
  features: string[];
}

const TOOLS: ToolCard[] = [
  {
    id: 'hashtag-generator',
    title: 'Instagram Hashtag Generator',
    description:
      'Categorized hashtags broken into High Reach, Targeted Niche, and Community tiers for 13 creator categories.',
    icon: Hash,
    accentColor: 'from-purple-600 to-indigo-600',
    features: ['13 Categories', 'Reels, Photos & Carousels', '3 Languages'],
  },
  {
    id: 'caption-generator',
    title: 'Viral Caption Generator',
    description:
      'Instantly generate 10 distinct caption hooks and punchlines across 8 tones with relevant emojis.',
    icon: MessageSquare,
    accentColor: 'from-pink-600 to-rose-600',
    features: ['8 Distinct Tones', '10 Captions at once', 'Instant Regenerate'],
  },
  {
    id: 'description-generator',
    title: 'Instagram Description Generator',
    description:
      'Craft long-form post descriptions, structured value carousels, and customizable call-to-action prompts.',
    icon: FileText,
    accentColor: 'from-indigo-600 to-blue-600',
    features: ['Short, Medium & Long', 'Selectable CTAs', 'Structured Flow'],
  },
  {
    id: 'tag-generator',
    title: 'Tag & Search Keyword Generator',
    description:
      'Extract algorithmic search phrases and SEO keyword tags that optimize your post for Instagram Explore search.',
    icon: Tag,
    accentColor: 'from-cyan-600 to-teal-600',
    features: ['Explore Search SEO', 'Alt Text Keywords', 'Comma-separated'],
  },
  {
    id: 'bio-generator',
    title: 'Instagram Bio Generator',
    description:
      'Transform your personal brand or business profile with formatted multi-line bios and live 150-char tracking.',
    icon: UserCheck,
    accentColor: 'from-emerald-600 to-teal-600',
    features: ['150-Char Live Tracker', '5 Aesthetic Styles', 'Emoji Toggle'],
  },
  {
    id: 'reels-captions',
    title: 'Reels Caption & Hook Generator',
    description:
      'Specialized 3-second visual hooks, loop captions, audio cues, and paired trending Reels tags.',
    icon: Video,
    accentColor: 'from-rose-600 to-orange-600',
    features: ['3-Second Hooks', 'Loop Captions', 'Audio Suggestions'],
  },
];

export const ToolCardsGrid: React.FC<ToolCardsGridProps> = ({ onSelectTool }) => {
  return (
    <section className="my-16">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Complete Instagram Growth Toolkit
        </h2>
        <p className="text-sm text-slate-400 mt-2">
          Select any tool below to instantly generate tailored copy, tags, and strategies for your next post.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {TOOLS.map((tool) => {
          const Icon = tool.icon;
          return (
            <div
              key={tool.id}
              onClick={() => onSelectTool(tool.id)}
              className="glass-panel glass-panel-hover rounded-2xl p-6 flex flex-col justify-between cursor-pointer group"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-11 h-11 rounded-xl bg-gradient-to-tr ${tool.accentColor} flex items-center justify-center text-white shadow-lg`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-mono text-slate-400 group-hover:text-purple-300 flex items-center gap-1 transition-colors">
                    <span>Open Tool</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">
                  {tool.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-4">
                  {tool.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex flex-wrap gap-1.5">
                {tool.features.map((feat) => (
                  <span
                    key={feat}
                    className="text-[11px] text-slate-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800"
                  >
                    {feat}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
