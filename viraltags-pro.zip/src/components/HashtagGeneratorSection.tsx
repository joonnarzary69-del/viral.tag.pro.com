import React, { useState } from 'react';
import {
  CATEGORIES,
  CONTENT_TYPES,
  LANGUAGES,
  CategoryKey,
  ContentType,
  Language,
  generateHashtags,
} from '../data/categories';
import { copyToClipboard, downloadAsTextFile } from '../utils/export';
import {
  Hash,
  Copy,
  Check,
  Download,
  RotateCcw,
  Sparkles,
  Layers,
  Globe2,
  Info,
} from 'lucide-react';

interface HashtagGeneratorSectionProps {
  onNotify: (msg: string) => void;
}

export const HashtagGeneratorSection: React.FC<HashtagGeneratorSectionProps> = ({
  onNotify,
}) => {
  const [topic, setTopic] = useState('');
  const [category, setCategory] = useState<CategoryKey>('Photography');
  const [contentType, setContentType] = useState<ContentType>('Instagram Reels');
  const [language, setLanguage] = useState<Language>('English');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedTag, setCopiedTag] = useState<string | null>(null);

  // Results state
  const [results, setResults] = useState<{
    highReach: string[];
    niche: string[];
    community: string[];
    formatTags: string[];
    all: string[];
  } | null>(() => generateHashtags('', 'Photography', 'Instagram Reels', 'English'));

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const generated = generateHashtags(topic, category, contentType, language);
      setResults(generated);
      setIsGenerating(false);
      onNotify('Generated curated hashtags successfully!');
    }, 250);
  };

  const handleClear = () => {
    setTopic('');
    setCategory('Photography');
    setContentType('Instagram Reels');
    setLanguage('English');
    const reset = generateHashtags('', 'Photography', 'Instagram Reels', 'English');
    setResults(reset);
    onNotify('Cleared input fields.');
  };

  const handleCopySingle = async (tag: string) => {
    const ok = await copyToClipboard(tag);
    if (ok) {
      setCopiedTag(tag);
      onNotify(`Copied ${tag}`);
      setTimeout(() => setCopiedTag(null), 1500);
    }
  };

  const handleCopyGroup = async (tags: string[], label: string) => {
    const text = tags.join(' ');
    const ok = await copyToClipboard(text);
    if (ok) {
      onNotify(`Copied all ${label} hashtags!`);
    }
  };

  const handleCopyAll = async () => {
    if (!results) return;
    const ok = await copyToClipboard(results.all.join(' '));
    if (ok) {
      onNotify('Copied all hashtags to clipboard!');
    }
  };

  const handleDownload = () => {
    if (!results) return;
    const content = `VIRALTAGS PRO - HASHTAG EXPORT
Category: ${category}
Content Type: ${contentType}
Language: ${language}
Topic: ${topic || 'General'}
Generated Date: ${new Date().toLocaleDateString()}

========================================
1. HIGH-REACH & POPULAR HASHTAGS:
${results.highReach.join(' ')}

========================================
2. TARGETED NICHE HASHTAGS:
${results.niche.join(' ')}

========================================
3. COMMUNITY & ENGAGEMENT HASHTAGS:
${results.community.join(' ')}

========================================
4. CONTENT FORMAT HASHTAGS (${contentType}):
${results.formatTags.join(' ')}

========================================
COMPLETE BUNDLE (${results.all.length} TAGS):
${results.all.join(' ')}
`;
    downloadAsTextFile(`viraltags_${category.toLowerCase()}_${Date.now()}.txt`, content);
    onNotify('Downloaded hashtags as .txt file!');
  };

  return (
    <section id="hashtag-generator" className="scroll-mt-24 my-12">
      <div className="glass-panel rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        {/* Glow backdrop subtle effect */}
        <div className="absolute -top-24 -right-24 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-80 h-80 bg-pink-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <Hash className="w-3.5 h-3.5" />
              <span>Smart Hashtag Engine</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Instagram Hashtag Generator
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Discover categorized hashtags tuned for your niche, content format, and regional language.
            </p>
          </div>
        </div>

        {/* Controls Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mb-8">
          {/* Topic Input */}
          <div className="md:col-span-12">
            <label
              htmlFor="hashtag-topic"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Post Topic / Keywords <span className="text-pink-400">*</span>
            </label>
            <div className="relative">
              <input
                id="hashtag-topic"
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Sunset golden hour street photography, gym leg workout, minimalist outfit"
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-white placeholder-slate-500 text-sm transition-all"
              />
              {topic && (
                <button
                  type="button"
                  onClick={() => setTopic('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white px-2 py-1 rounded"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Category Select */}
          <div className="md:col-span-4">
            <label
              htmlFor="hashtag-category"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2"
            >
              Category ({CATEGORIES.length})
            </label>
            <div className="relative">
              <select
                id="hashtag-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as CategoryKey)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-purple-500 text-white text-sm appearance-none cursor-pointer"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat} className="bg-slate-900 text-white">
                    {cat}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>

          {/* Content Type */}
          <div className="md:col-span-4">
            <label
              htmlFor="hashtag-content-type"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5"
            >
              <Layers className="w-3.5 h-3.5 text-pink-400" />
              Content Format
            </label>
            <div className="relative">
              <select
                id="hashtag-content-type"
                value={contentType}
                onChange={(e) => setContentType(e.target.value as ContentType)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-purple-500 text-white text-sm appearance-none cursor-pointer"
              >
                {CONTENT_TYPES.map((type) => (
                  <option key={type} value={type} className="bg-slate-900 text-white">
                    {type}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>

          {/* Language Selection */}
          <div className="md:col-span-4">
            <label
              htmlFor="hashtag-language"
              className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5"
            >
              <Globe2 className="w-3.5 h-3.5 text-purple-400" />
              Language
            </label>
            <div className="relative">
              <select
                id="hashtag-language"
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-purple-500 text-white text-sm appearance-none cursor-pointer"
              >
                {LANGUAGES.map((lang) => (
                  <option key={lang.id} value={lang.id} className="bg-slate-900 text-white">
                    {lang.native}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating}
            className="gradient-button flex items-center gap-2 px-6 py-3.5 rounded-xl text-white font-semibold text-sm shadow-lg disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Analyzing Taxonomy...' : 'Generate Hashtags'}</span>
          </button>

          <button
            type="button"
            onClick={handleClear}
            className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Clear</span>
          </button>

          {results && (
            <>
              <button
                type="button"
                onClick={handleCopyAll}
                className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-purple-600/20 border border-purple-500/40 hover:bg-purple-600/30 text-purple-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
              >
                <Copy className="w-4 h-4" />
                <span>Copy All ({results.all.length})</span>
              </button>

              <button
                type="button"
                onClick={handleDownload}
                className="flex items-center gap-1.5 px-4 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download .txt</span>
              </button>
            </>
          )}
        </div>

        {/* Algorithmic transparency note */}
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-400 flex items-start gap-2.5 mb-8">
          <Info className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
          <p>
            <strong>Realistic Reach Notice:</strong> Hashtags help Instagram's recommendation index categorize your visual subject matter. They do not guarantee viral metrics; total explore reach also depends on retention watch time, shares, and engagement.
          </p>
        </div>

        {/* Results Sections Categorized */}
        {results && (
          <div className="space-y-6">
            {/* 1. High Reach */}
            <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800/90">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                  <h3 className="text-sm font-semibold text-white">
                    High-Reach &amp; Popular Tags ({results.highReach.length})
                  </h3>
                  <span className="text-xs text-slate-400">Broad category search</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyGroup(results.highReach, 'High-Reach')}
                  className="text-xs text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Bucket</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {results.highReach.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleCopySingle(tag)}
                    className="group px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-purple-500/60 text-xs text-purple-200 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>{tag}</span>
                    {copiedTag === tag ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3 text-slate-500 group-hover:text-purple-300 opacity-60 group-hover:opacity-100" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Targeted Niche */}
            <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800/90">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-pink-500" />
                  <h3 className="text-sm font-semibold text-white">
                    Targeted Niche Tags ({results.niche.length})
                  </h3>
                  <span className="text-xs text-slate-400">Lower competition, high relevance</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyGroup(results.niche, 'Targeted Niche')}
                  className="text-xs text-pink-400 hover:text-pink-300 font-medium flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Bucket</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {results.niche.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleCopySingle(tag)}
                    className="group px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-pink-500/60 text-xs text-pink-200 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>{tag}</span>
                    {copiedTag === tag ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3 text-slate-500 group-hover:text-pink-300 opacity-60 group-hover:opacity-100" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Community Tags */}
            <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800/90">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <h3 className="text-sm font-semibold text-white">
                    Community &amp; Engagement Tags ({results.community.length})
                  </h3>
                  <span className="text-xs text-slate-400">Active creator interaction</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyGroup(results.community, 'Community')}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Bucket</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {results.community.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleCopySingle(tag)}
                    className="group px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-emerald-500/60 text-xs text-emerald-200 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>{tag}</span>
                    {copiedTag === tag ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3 text-slate-500 group-hover:text-emerald-300 opacity-60 group-hover:opacity-100" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* 4. Format Tags */}
            <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800/90">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  <h3 className="text-sm font-semibold text-white">
                    Format Specific Tags: {contentType} ({results.formatTags.length})
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyGroup(results.formatTags, contentType)}
                  className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Bucket</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {results.formatTags.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleCopySingle(tag)}
                    className="group px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-blue-500/60 text-xs text-blue-200 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>{tag}</span>
                    {copiedTag === tag ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3 text-slate-500 group-hover:text-blue-300 opacity-60 group-hover:opacity-100" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
