import React, { useState } from 'react';
import { Menu, X, Sparkles, Hash, MessageSquare, UserCheck, Video } from 'lucide-react';

interface NavigationProps {
  onOpenAbout: () => void;
  onOpenContact: () => void;
  activeSection?: string;
}

export const Navigation: React.FC<NavigationProps> = ({
  onOpenAbout,
  onOpenContact,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#09090f]/85 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16 sm:h-20">
          {/* Zone 1: Brand wordmark */}
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0 group focus:outline-none"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-600 via-fuchsia-500 to-pink-500 flex items-center justify-center shadow-md shadow-purple-900/40 group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg sm:text-xl font-bold tracking-tight text-white">
              ViralTags <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">Pro</span>
            </span>
          </a>

          {/* Zone 2: Navigation Links */}
          <nav
            aria-label="Main Navigation"
            className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-medium text-slate-300"
          >
            <button
              type="button"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Home
            </button>
            <button
              type="button"
              onClick={() => scrollTo('hashtag-generator')}
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Hashtag Generator
            </button>
            <button
              type="button"
              onClick={() => scrollTo('caption-generator')}
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Caption Generator
            </button>
            <button
              type="button"
              onClick={() => scrollTo('bio-generator')}
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Bio Generator
            </button>
            <button
              type="button"
              onClick={onOpenAbout}
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              About
            </button>
            <button
              type="button"
              onClick={onOpenContact}
              className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Contact
            </button>
          </nav>

          {/* Zone 3: Primary CTA button */}
          <div className="hidden md:flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => scrollTo('hashtag-generator')}
              className="gradient-button px-4 py-2 text-xs sm:text-sm font-semibold text-white rounded-xl shadow-md cursor-pointer whitespace-nowrap shrink-0"
            >
              Generate Now
            </button>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              type="button"
              onClick={() => scrollTo('hashtag-generator')}
              className="gradient-button px-3 py-1.5 text-xs font-semibold text-white rounded-lg shadow-sm"
            >
              Generate
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-900 border border-slate-800 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0e0e18] border-b border-slate-800 px-4 pt-3 pb-6 space-y-2 animate-fade-in shadow-2xl">
          <button
            type="button"
            onClick={() => {
              window.scrollTo({ top: 0, behavior: 'smooth' });
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-lg hover:bg-slate-800/60 text-slate-200 text-sm font-medium"
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => scrollTo('hashtag-generator')}
            className="w-full text-left py-2.5 px-3 rounded-lg hover:bg-slate-800/60 text-slate-200 text-sm font-medium flex items-center gap-2"
          >
            <Hash className="w-4 h-4 text-purple-400" />
            <span>Hashtag Generator</span>
          </button>
          <button
            type="button"
            onClick={() => scrollTo('caption-generator')}
            className="w-full text-left py-2.5 px-3 rounded-lg hover:bg-slate-800/60 text-slate-200 text-sm font-medium flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4 text-pink-400" />
            <span>Caption Generator</span>
          </button>
          <button
            type="button"
            onClick={() => scrollTo('description-generator')}
            className="w-full text-left py-2.5 px-3 rounded-lg hover:bg-slate-800/60 text-slate-200 text-sm font-medium"
          >
            Description Generator
          </button>
          <button
            type="button"
            onClick={() => scrollTo('tag-generator')}
            className="w-full text-left py-2.5 px-3 rounded-lg hover:bg-slate-800/60 text-slate-200 text-sm font-medium"
          >
            SEO Tag &amp; Keyword Generator
          </button>
          <button
            type="button"
            onClick={() => scrollTo('bio-generator')}
            className="w-full text-left py-2.5 px-3 rounded-lg hover:bg-slate-800/60 text-slate-200 text-sm font-medium flex items-center gap-2"
          >
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Bio Generator</span>
          </button>
          <button
            type="button"
            onClick={() => scrollTo('reels-captions')}
            className="w-full text-left py-2.5 px-3 rounded-lg hover:bg-slate-800/60 text-slate-200 text-sm font-medium flex items-center gap-2"
          >
            <Video className="w-4 h-4 text-rose-400" />
            <span>Reels Caption Generator</span>
          </button>
          <div className="pt-2 border-t border-slate-800 flex gap-2">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAbout();
              }}
              className="flex-1 py-2 px-3 rounded-lg bg-slate-900 text-slate-300 text-xs font-medium text-center"
            >
              About Us
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenContact();
              }}
              className="flex-1 py-2 px-3 rounded-lg bg-slate-900 text-slate-300 text-xs font-medium text-center"
            >
              Contact Support
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
