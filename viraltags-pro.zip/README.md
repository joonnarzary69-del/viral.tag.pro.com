# ViralTags Pro 🚀

> **Create Better Content. Discover Better Hashtags.**

ViralTags Pro is a complete, modern, mobile-friendly web application designed for Instagram creators, influencers, and brands to generate high-relevance hashtags, engaging caption hooks, formatted post descriptions, SEO keyword search tags, aesthetic bios, and Reels content packages.

---

## 🌟 Key Features

1. **Instagram Hashtag Generator**
   - 13 Curated Categories: Gaming, Photography, Fashion, Travel, Fitness, Education, Motivation, Love, Comedy, Food, Technology, Lifestyle, Business.
   - 3 Content Formats: Instagram Reels, Photo, Carousel.
   - 3 Languages: English, Hindi (हिन्दी), and Assamese (অসমীয়া).
   - Categorized buckets: High-Reach Popular, Targeted Niche, Community, and Format tags.
   - 1-Click single tag copy, bucket copy, Copy All, and `.txt` file export.

2. **Viral Caption Generator**
   - 10 distinct caption hooks generated at once with contextual emojis.
   - 8 Tones: Funny, Cool, Emotional, Romantic, Motivational, Professional, Attitude, Inspirational.
   - Individual Copy buttons and instant Regenerate variations.

3. **Instagram Description Generator**
   - 3 Length tiers: Short (~150 words), Medium (~300 words), Long deep dive (~500 words).
   - Structured flow: Headline hook, body storytelling, call-to-action (CTA), and paired tags.
   - 5 Selectable CTAs: Save for later, Share with friends, Comment thoughts, Link in bio, Double tap.

4. **Instagram Tag & SEO Keyword Generator**
   - Discovers high-intent search terms for Instagram's Explore search algorithm and alt text.
   - Primary keywords, secondary niche phrases, comma-separated sets, and tag bundles.

5. **Instagram Bio Generator**
   - 5 Aesthetic styles: Aesthetic & Clean, Creator & Influencer, Business & Coach, Punchy & Attitude, Poetic & Mindful.
   - Real-time 150-character limit counter with color-coded safety indicators.
   - Emoji toggle (Include / Clean text).

6. **Dedicated Reels Caption Generator**
   - Specialized 3-second visual hooks ("Watch till the end...", "POV: ...", "Loop this 🔁").
   - Catchy caption body + audio prompt recommendations + paired Reels hashtags.

7. **Monetization & AdSense Readiness**
   - Reserved advertising slots (Leaderboard 728x90, In-Feed, Medium Rectangle).
   - Clear guidelines and non-intrusive container markup ready for approved Google AdSense publisher tags.
   - No fake ads or deceptive click triggers.

8. **Security & Privacy**
   - 100% Free, no Instagram login or account credentials required.
   - Zero password collection; runs directly inside the client browser.
   - Dedicated Privacy Policy, Terms and Conditions, and Contact modal.

---

## 🛠️ Technology Stack

- **HTML5 & Modern CSS3** with dark obsidian styling, purple gradients, and pink accents.
- **React 19 + TypeScript + Vite**.
- **Tailwind CSS v4** with clean typography (Plus Jakarta Sans).
- **Lucide React** icons.

---

## 🚀 How to Run Locally

```bash
# Install dependencies
npm install

# Start the local development server
npm run dev
```

Visit `http://localhost:3000` in your browser.

---

## 🌐 Free Deployment (GitHub Pages, Netlify, Vercel)

### Option 1: GitHub Pages
1. Build the production files:
   ```bash
   npm run build
   ```
2. Commit and push your code to a public GitHub repository.
3. In your GitHub repository, navigate to **Settings > Pages**.
4. Under **Source**, select **Deploy from a branch** and choose the `dist` or `gh-pages` branch (or select GitHub Actions for automatic Vite deployment).
5. Your website will be live at `https://yourusername.github.io/viraltags-pro/`.

### Option 2: Netlify Drop (1-Click)
1. Run `npm run build`.
2. Visit [Netlify Drop](https://app.netlify.com/drop).
3. Drag and drop the generated `dist/` folder.
4. Your site will immediately go live with free SSL!

---

## 📜 License

Created for Instagram content creators. Free to use and distribute.
